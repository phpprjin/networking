<?php
$content = file($_SERVER['DOCUMENT_ROOT'] .'/rconfig/www/licenseCheck.txt');
$checkLicenseValue = intval($content[0]);
echo json_encode($checkLicenseValue);