<?php
// include our OAuth2 Server object 
require_once __DIR__.'/server.php';

// Handle a request to a resource and authenticate the access token
if (!$server->verifyResourceRequest(OAuth2\Request::createFromGlobals())) {
    $server->getResponse()->send();
    die;
}


include "connectdb.php";
$query="select * from users";
			$rs=$dbhandle->query($query);

			while ($row = $rs->fetch_assoc()) {
			  $resdata[] = $row;
			}

print(json_encode(array('success' => true, 'message' => 'You accessed my APIs!', 'data' => $resdata)));